package pkg1;

public class ClassA {
	void m1() {
	}
	
	void m2() {
	}

	void m3() {
	}
}

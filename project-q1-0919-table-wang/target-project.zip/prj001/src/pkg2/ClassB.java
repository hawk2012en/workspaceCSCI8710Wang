package pkg2;

public class ClassB {
	public void foo() {
	}
	
	public void bar() {
	}

	public void baz() {
	}
}

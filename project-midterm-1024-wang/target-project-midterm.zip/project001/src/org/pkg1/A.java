package org.pkg1;

public class A {
	private void ma1(String str1) {}
	void ma2(String str2, int i1) {
		ma1(str2);
	}
}

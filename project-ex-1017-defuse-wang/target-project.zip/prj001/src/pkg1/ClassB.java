package pkg1;

public class ClassB {
	public void mb1(int position, String buffer) {
		String dataB = buffer;
		int indexB = position / 100;

		if (indexB < 0) {
			indexB = -1 * indexB;
			System.out.println(dataB.charAt(indexB));
		} else {
			indexB = indexB + 1;
			System.out.println(dataB.charAt(indexB));
		}
	}

	public int mb2(int x, int y) {
		int resultB = 0;
		resultB = x > y ? x - y : y - x;
		return resultB;
	}
}
